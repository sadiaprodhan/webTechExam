<html>
<head> 
<title> Registration </title> </head>
<body>
<form>
<table width= "100%" height="60%">
<tr> 
<td  colspan="2" align = "right" > <p align="left"> XCompany </p>
 
<a href="PublicHome.html" > Home</a>
<a href="Login.php"> Login</a>
<a href="Registration.php"> Registration</a>  <hr> </hr> </td>
</tr> 





<tr>
<td colspan="2"  height= "70%">
<fieldset width="60%" height= "90%" align= "center"> 
<legend> Registration </legend>
<table  align= "center">
<tr>
<td>
Name:
</td> <td> </td>
<td> <input type "text" name="uname">  </td> </tr>
<tr> 
<td colspan="3"> 
<hr> </hr> </td> </tr>
<tr>
<td>
Email:
</td> <td> </td>
<td> <input type "text" name="email">  </td> </tr>
<td colspan="3"> 
<hr> </hr> </td> </tr>
<tr>
<td>
Password
</td> <td> </td>
<td> <input type "password" name="pass">  </td> </tr>
<td colspan="3"> 
<hr> </hr> </td> </tr>
<tr>
<td>
Confirm Password:
</td> <td> </td>
<td> <input type "password" name="confirm">  </td> </tr>
<td colspan="3"> 
<hr> </hr> </td> </tr>

<tr> 
<td colspan="3"> 
<fieldset width="60%" height= "90%" align= "center"> 
<legend> Gender</legend>

<input type = "radio" name="gender" value="Male"> Male  
<input type = "radio" name="gender" value="Female"> Female 
<input type = "radio" name="gender" value="Other"> Other 
</fieldset> </td> </tr>
<td colspan="3"> 
<hr> </hr> </td> </tr>
<tr> 
<td colspan="3">

<fieldset width="60%" height= "90%" align= "center"> 
<legend> Date Of Birth</legend>

<input type = "text" name="day" >/
<input type = "text" name="month" >/ 
<input type = "text" name="year" >( <i> dd /mm /yy </i>)
</fieldset>
</td> </tr> 
<td colspan="3"> 
<hr> </hr> </td> </tr>
<td colspan="3"> 
<input type="submit" name= "submit" value="submit">
<input type="reset" name= "submit" value="reset"> </td> </tr>


</table>
<hr> </hr> </td>


</tr>
<tr>
<td colspan="2" align= "center"> Copyright � 2017
<br>
<hr> </hr> </td>

 
 



</html>