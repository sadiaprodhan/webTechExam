<html>
<head> 
<title> Login </title> </head>
<body>
<form>
<table width= "100%" height="60%">
<tr> 
<td  colspan="2" align = "right" > <p align="left"> XCompany </p>
 
<a href="PublicHome.html" > Home</a>
<a href="Login.php"> Login</a>
<a href="Registration.php"> Registration</a>  <hr> </hr> </td>
</tr> 
<tr>
<td colspan="2" >
<fieldset width="60%" height= "50%" align= "center"> 
<legend> Login</legend>
<table align= "center"> 
<tr>
<td>
User Name: </td> <td> <input type "text" name="uname"> </td> </tr>
<tr>
<td>Password: </td> <td> <input type "password" name="pass"> </td> </tr>
<tr>
<td colspan= "2"> <hr> </hr> 
<input type= "checkbox" name="value" value="options[]"> Remember Me  <br> <br>
<input type="submit" name= "submit" value="submit"> <a href= "forgetpass.php"> Forget Password? </a>

</td> </tr> 

</fieldset>
 </td>

</table>
</tr>
<tr>
<td colspan="2" align= "center"> Copyright � 2017
<br>
<hr> </hr> </td>

 
 



</html>